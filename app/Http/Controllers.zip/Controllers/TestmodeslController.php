<?php

namespace App\Http\Controllers;

use App\Models\testmodesl;
use App\Http\Requests\StoretestmodeslRequest;
use App\Http\Requests\UpdatetestmodeslRequest;

class TestmodeslController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoretestmodeslRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoretestmodeslRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\testmodesl  $testmodesl
     * @return \Illuminate\Http\Response
     */
    public function show(testmodesl $testmodesl)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\testmodesl  $testmodesl
     * @return \Illuminate\Http\Response
     */
    public function edit(testmodesl $testmodesl)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatetestmodeslRequest  $request
     * @param  \App\Models\testmodesl  $testmodesl
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatetestmodeslRequest $request, testmodesl $testmodesl)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\testmodesl  $testmodesl
     * @return \Illuminate\Http\Response
     */
    public function destroy(testmodesl $testmodesl)
    {
        //
    }
}
