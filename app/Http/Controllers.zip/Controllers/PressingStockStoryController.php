<?php

namespace App\Http\Controllers;

use App\Models\pressingStockStory;
use App\Http\Requests\StorepressingStockStoryRequest;
use App\Http\Requests\UpdatepressingStockStoryRequest;

class PressingStockStoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorepressingStockStoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorepressingStockStoryRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\pressingStockStory  $pressingStockStory
     * @return \Illuminate\Http\Response
     */
    public function show(pressingStockStory $pressingStockStory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\pressingStockStory  $pressingStockStory
     * @return \Illuminate\Http\Response
     */
    public function edit(pressingStockStory $pressingStockStory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatepressingStockStoryRequest  $request
     * @param  \App\Models\pressingStockStory  $pressingStockStory
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatepressingStockStoryRequest $request, pressingStockStory $pressingStockStory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\pressingStockStory  $pressingStockStory
     * @return \Illuminate\Http\Response
     */
    public function destroy(pressingStockStory $pressingStockStory)
    {
        //
    }
}
